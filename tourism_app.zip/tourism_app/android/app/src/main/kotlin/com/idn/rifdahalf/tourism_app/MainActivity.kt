package com.idn.rifdahalf.tourism_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
