class Tourisms{
  String name, address, description, schedule, ticket, photo;
  List<String> imgurl;

  Tourisms ({
    this.name,
    this.address,
    this.description,
    this.schedule,
    this.ticket,
    this.photo,
    this.imgurl,
});
}